
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export default function TradingDemoApp() {
  const [step, setStep] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [score, setScore] = useState(0);

  const challenges = [
    {
      title: "Challenge 1: Buy BTC when RSI < 30",
      instruction: "Assume RSI = 25. Do you BUY or WAIT?",
      options: ["BUY", "WAIT"],
      correct: "BUY",
      feedback: {
        BUY: "Correct! RSI below 30 often means asset is oversold.",
        WAIT: "Incorrect. RSI < 30 typically signals a buy opportunity."
      }
    },
    {
      title: "Challenge 2: Use Stop Loss",
      instruction: "You bought ETH at $1800. Price dropped to $1750. What do you do?",
      options: ["HOLD", "CLOSE TRADE"],
      correct: "CLOSE TRADE",
      feedback: {
        "CLOSE TRADE": "Well done. A stop loss helps minimize your loss.",
        HOLD: "Not ideal. You risk losing more without a stop loss."
      }
    },
    {
      title: "Challenge 3: Trend Analysis",
      instruction: "Price is forming higher highs and higher lows. What trend is this?",
      options: ["UPTREND", "DOWNTREND"],
      correct: "UPTREND",
      feedback: {
        UPTREND: "Perfect. That’s a classic uptrend.",
        DOWNTREND: "Incorrect. Higher highs/lows = uptrend."
      }
    }
  ];

  const handleChoice = (option) => {
    const current = challenges[step];
    setFeedback(current.feedback[option]);
    if (option === current.correct) setScore((prev) => prev + 1);
    setTimeout(() => {
      setFeedback("");
      if (step < challenges.length - 1) setStep((prev) => prev + 1);
    }, 2500);
  };

  return (
    <div className="p-6 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold text-center">🧠 Trading Demo Challenge</h1>

      <Card>
        <CardContent className="p-4 space-y-3">
          <h2 className="text-xl font-semibold">
            {challenges[step].title}
          </h2>
          <p>{challenges[step].instruction}</p>
          <div className="flex gap-4 mt-2">
            {challenges[step].options.map((option) => (
              <Button key={option} onClick={() => handleChoice(option)}>
                {option}
              </Button>
            ))}
          </div>
          {feedback && <p className="mt-2 text-sm text-gray-700">{feedback}</p>}
        </CardContent>
      </Card>

      <Progress value={(score / challenges.length) * 100} />
      <p className="text-center">
        Score: {score} / {challenges.length}
      </p>
    </div>
  );
}
