# Irene Trading Teacher

This is a demo trading app built using React that provides challenges to help users learn how to trade through simulation.